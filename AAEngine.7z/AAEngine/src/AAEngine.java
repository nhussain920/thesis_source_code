

import org.adapter.AADepression;
import org.adapter.AASuicide;
import org.adapter.AASocial;


public class AAEngine {
	
	public static void main(String[] args) {

		AADepression depression_aa = new AADepression();
		AASuicide suicide_aa = new AASuicide();
		AASocial social_aa = new AASocial();
	}
	
}
