package org.domain;

import org.manager.ActionImpl;
import org.manager.GlobalRIE;
import org.manager.LocalRIE;
import org.manager.PolicyData;

public class AA1LocalRIE_Depression extends LocalRIE {
	private AA1Monitor_Depression monitor;
	protected String rieID;
	private PolicyData policyData;
	private ActionImpl callAction;
	private boolean notification;
	private boolean context1, context2;
	public static String trigger_action = null;
	private GlobalRIE gRIE;
	
	public AA1LocalRIE_Depression(String rieID) {
		this.rieID = rieID;
		this.monitor = new AA1Monitor_Depression("");
		this.callAction = new ActionImpl();
		this.policyData = new PolicyData();
		this.monitor.setContext();
		this.notification = false;
		this.context1 = false;
		this.context2 = false;
	}
	
	public boolean getNotified(AA1Monitor_Depression m) {
		if(m.notifyLocalRIE() == true) {
			System.out.println("Local RIE received notification from Monitor: " + m.toString());
			this.notification = true;
			return true;
		}
		
		return false;
	}
	
	public boolean notifyGlobalRIE() {
		if(this.notification == true) {
			System.out.println("Local RIE: " + rieID + " notified Global RIE");
			return true;
		}
		
		return false;
	}
	
	public void triggerAction() {
		int i = 0;
		for(i=0; i<monitor.getContext().length; i++) {
			if( monitor.context[i].equals(policyData.getExpression1().get(i)) && 
				monitor.context[++i].equals(policyData.getExpression1().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression1().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression1().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression1().get(i))) {
				System.out.println("Context 1 is true");
				System.out.println("Trigger action template send_email");
				AA1LocalRIE_Depression.trigger_action = "a1";
				
			}
		}
		
		i = 0;
			if( monitor.context[i].equals(policyData.getExpression2().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression2().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression2().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression2().get(i)) &&
				monitor.context[++i].equals(policyData.getExpression2().get(i))) {
				System.out.println("Context 2 is true");
				System.out.println("Trigger action template open_url");
				AA1LocalRIE_Depression.trigger_action = "a2";
				
			}
			/*
			if( monitor.context[i].equals("high") && monitor.context[++i].equals("likely") &&
				monitor.context[++i].equals("likely") && monitor.context[++i].equals("likely") &&
				monitor.context[++i].equals("unlikely")) {
				System.out.println("Context 3 true");
				System.out.println("Trigger action template dial_emergency");
				callAction.dialEmergency();
			}
			
			if(monitor.context[i].equals("critical") && monitor.context[++i].equals("likely") &&
				monitor.context[++i].equals("likely") && monitor.context[++i].equals("likely") &&
				monitor.context[++i].equals("likely")) {
				System.out.println("Context 4 true");
				System.out.println("Trigger action template dial_emergency");
				callAction.dialEmergency();
			}*/
		//}
	}
	
	
	public String getAction() {
		return trigger_action;
	}
	
	public void printAction() {
	System.out.println("Triggered Action ID: " + trigger_action);
	}
	
	public String toString() {
		return "AA1 Local RIE: " + rieID;
	}

}
