package org.domain;

import org.manager.ActionImpl;
import org.manager.Executor;
import org.manager.GlobalRIE;
import org.manager.PolicyData;

public class AA1Executor_Depression extends Executor {
	private String executorID;
	private String commandID, actionID, adapterID;
	private boolean notification;
	private PolicyData policy;
	private ActionImpl action;
	
	public AA1Executor_Depression(String executorID) {
		this.executorID = executorID;
		this.notification = false;
		action = new ActionImpl();
	}
	
	public boolean getNotified(GlobalRIE rie) {
		if(rie.notifyExecutor() == true) {
			System.out.println("Executor received notification from: " + rie.toString());
			this.notification = true;
			return true;
		}
		
		return false;
	}
	
	public void getCommand(String commandID, String actionID, String adapterID) {
		this.commandID = commandID;
		this.actionID = actionID;
		this.adapterID = adapterID;
		System.out.println(adapterID + " adapter recieved command: " + commandID + " from" + 
				" Global RIE to execute action: " + actionID);
		
	}
	
	public void executeAction() {
		String id = policy.node_id;
		String name = policy.name;
		String recepient = policy.recepient;
		String subject = policy.subject;
		String txtMessage = policy.txtMessage;
		String population_restriction = policy.population_restriction;
		action.sendEmail(id, name, recepient, subject, txtMessage, population_restriction);
	}
	
	public void applyChanges() {
		
	}
	
	
	public String toString() {
		return "Executor: " + executorID;
	}

}
