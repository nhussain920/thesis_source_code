package org.domain;

import org.manager.AASensor;
import org.manager.ManagedResource;
import org.manager.Monitor;
import org.manager.PolicyData;
import org.manager.Resource;

public class AA1Monitor_Depression extends Monitor {

	private ManagedResource mr;
	private AASensor sensor;
	private PolicyData policyData;
	private boolean notification;
	private String depContext, voiceContext, voiceUrgeSelf, voiceUrgeOther, delusions;
	private String monitorID;
	private String sensorData;
	protected String[] context;
	
	public AA1Monitor_Depression(String monitorID) {
		mr = new ManagedResource(new Resource("","",""));
		sensor = new AASensor("","");
		policyData = new PolicyData();
		this.monitorID = monitorID;
		this.notification = false;
		this.context = new String[5];
	}
	
	public boolean getNotified(AASensor s) {
		if(s.notifyMonitor() == true) {
			System.out.println("Monitor received notification from sensor: " + s.toString());
			this.notification = true;
			return true;
		}
		
		return false;
	}
	
	public boolean notifyLocalRIE() {
		if(notification == true) {
			System.out.println("Monitor " + monitorID + " notified AA's Local RIE");
			return true;
		}
		
		return false;
	}
	
	public void retrieveSensorData() {
		System.out.print("Sensor's Data: [");
		for(int i=0; i< mr.getEvents().size(); i++) {
			sensorData = mr.getEvents().get(i);
			System.out.print(" "+ sensorData + ",");
		}
		System.out.println("] added to Monitor\n");
	}
	
	public void setContext() {
		for(int i=0; i<mr.getEvents().size(); i++){
			if(mr.getEvents().contains(policyData.getDepressionData().get(i))){
			depContext = "low";
			context[0] = depContext;
			}
			
			if(mr.getEvents().contains(policyData.getVoiceActData().get(i))){
				voiceContext = "likely";
				context[1] = voiceContext;
			}
			
			if(mr.getEvents().contains(policyData.getVoiceUrgeSelf().get(i))){
				voiceUrgeSelf = "unlikely";
				context[2] = voiceUrgeSelf;
			}
			
			if(mr.getEvents().contains(policyData.getVoiceUrgeOther().get(i))){
				voiceUrgeOther = "unlikely";
				context[3] = voiceUrgeOther;
			}
			
			if(mr.getEvents().contains(policyData.getDelusions().get(i))){
				delusions = "likely";
				context[4] = delusions;
			}
		}
	}
	
	public void printContext() {
		System.out.println("Setting context variables...");
		System.out.println("New context variable set for 'Depression' Node : " + depContext);
		System.out.println("New context variable set for 'Act On Voice' Node: " + voiceContext);
		System.out.println("New context variable set for 'Voice Urge Harm Self' Node: " + voiceUrgeSelf);
		System.out.println("New context variable set for 'Voice Urge Harm Others' Node: " + voiceUrgeOther);
		System.out.println("New context variable set for 'Delusions' Node: " + delusions);
	}

	public String[] getContext() {
		return this.context;
	}

	public String toString() {
		return "Monitor " + monitorID;
	}


}
