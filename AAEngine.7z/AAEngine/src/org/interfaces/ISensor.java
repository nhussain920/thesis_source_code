package org.interfaces;

import org.manager.Resource;

public interface ISensor {
	//method to update the sensor, used by managed resource
	public void update(Resource resource, String eventData);

}
