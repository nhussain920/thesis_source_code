package org.interfaces;

public interface IManagedResource {
	//methods to register and unregister sensors
	public void registerSensor(ISensor sensor);
	public void unregisterSensor(ISensor sensor);
	
	//method to notify sensors of change
	public void notifySensor(String eventData);
	
	//method to get updates from subject
	public Object getUpdate(ISensor obj);

}
