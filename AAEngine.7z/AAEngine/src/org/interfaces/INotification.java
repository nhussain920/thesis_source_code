package org.interfaces;

public interface INotification {
	
	public boolean notified();

}