package org.adapter;
import org.domain.AA1Monitor_Depression;
import org.manager.AASensor;
import org.manager.ManagedResource;
import org.manager.Resource;

public class AASuicide {
	ManagedResource suicide_attempt;
	ManagedResource more_attempt;
	ManagedResource number_of_attempt;
	
	AASensor sensor1, sensor2, sensor3;
	
	AASensor tempSensor;
	AA1Monitor_Depression m;
	Resource r;
	ManagedResource test;
	
	public AASuicide()
	{
		suicide_attempt = new ManagedResource(new Resource("1", "Has Suicide Attempt", "S1")) ;
		more_attempt = new ManagedResource(new Resource("2", "More than one attempt", "S2"));
		number_of_attempt = new ManagedResource(new Resource("3", "Total number of attempt", "S3"));
		
		test = new ManagedResource(new Resource("", "", ""));
		tempSensor = new AASensor("22","22");
				
		sensor1 = new AASensor("S1", "AA2 Suicide Attempt Sensor");
		sensor2 = new AASensor("S2", "AA2 Attemp Count Sensor");
		sensor3 = new AASensor("S3", "AA2 Attempt Number Sensor");
		
		suicide_attempt.registerSensor(sensor1);
		more_attempt.registerSensor(sensor2);
		number_of_attempt.registerSensor(sensor3);
		
		suicide_attempt.setEvent("yes");
		more_attempt.setEvent("yes");
		number_of_attempt.setEvent("1");
		
		System.out.println("Senosr's Data " + test.getEvents() + " added to Monitor");
		m= new AA1Monitor_Depression("m1");
		m.getNotified(sensor1);
		m.getNotified(sensor2);
		m.getNotified(sensor3);
		
		
		//m.setContext1();
		
	}
	
}
