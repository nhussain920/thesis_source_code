package org.adapter;

import java.util.concurrent.Executor;

import org.domain.AA1Executor_Depression;
import org.domain.AA1LocalRIE_Depression;
import org.domain.AA1Monitor_Depression;
import org.manager.AASensor;
import org.manager.GlobalRIE;
import org.manager.ManagedResource;
import org.manager.Resource;


public class AADepression {
	ManagedResource depression_status;
	ManagedResource act_on_voice;
	ManagedResource voice_urge_harm_self;
	ManagedResource voice_urge_harm_others;
	ManagedResource delusions;
	ManagedResource mr;
	AASensor sensor, sensor1, sensor2, sensor3, sensor4, sensor5;
	AA1Monitor_Depression monitor;
	AA1LocalRIE_Depression aa1_rie;
	AA1Executor_Depression aa1_executor;

	GlobalRIE globalRIE;
		
	public AADepression() {
		depression_status = new ManagedResource(new Resource("mr1", "Depression Status", "s1"));	
		act_on_voice = new ManagedResource(new Resource("mr2", "Act On Voice", "s2"));
		voice_urge_harm_self = new ManagedResource(new Resource("mr3", "voice_urge_harm_self", "s3"));
		voice_urge_harm_others = new ManagedResource(new Resource("mr4", "voice_urge_harm_others", "s4"));
		delusions = new ManagedResource(new Resource("mr5", "delusions", "s5"));
		
		sensor1 = new AASensor("S1", "AA1 Depression Sensor");
		sensor2 = new AASensor("S2", "AA1 Act on Voice Sensor");
		sensor3 = new AASensor("S3", "AA1 Voice Urge Self Sensor");
		sensor4 = new AASensor("S4", "AA1 Voice Urge Other Sensor");
		sensor5 = new AASensor("S5", "AA1 Delusion Sensor");
		
		depression_status.registerSensor(sensor1);
		act_on_voice.registerSensor(sensor2);
		voice_urge_harm_self.registerSensor(sensor3);
		voice_urge_harm_others.registerSensor(sensor4);
		delusions.registerSensor(sensor5);
		
		depression_status.setEvent("first-diagnosis");
		act_on_voice.setEvent("0.6");
		voice_urge_harm_self.setEvent("0.2");
		voice_urge_harm_others.setEvent("0.4");
		delusions.setEvent("0.7");
		
		mr = new ManagedResource(new Resource("", "", ""));
		sensor = new AASensor("22","22");
		sensor.retrieveEventData();
		
		monitor= new AA1Monitor_Depression("m1");
		monitor.getNotified(sensor1);
		monitor.getNotified(sensor2);
		monitor.getNotified(sensor3);
		monitor.getNotified(sensor4);
		monitor.getNotified(sensor5);
		monitor.retrieveSensorData();
		
		monitor.setContext();
		monitor.printContext();
		System.out.println("\n");
		
		aa1_rie = new AA1LocalRIE_Depression("aa-rie1");
		aa1_rie.getNotified(monitor);
		aa1_rie.triggerAction();
		aa1_rie.printAction();
		System.out.println("\n");
		
		globalRIE = new GlobalRIE("GlobalRIE");
		globalRIE.getNotified(aa1_rie);
		globalRIE.addActions();
		globalRIE.decision();
		globalRIE.printAction();
		System.out.println("\n");
		
		aa1_executor = new AA1Executor_Depression("AA1 Executor");
		aa1_executor.getNotified(globalRIE);
		aa1_executor.executeAction();
		//aa1_executor.getCommand(commandID, actionID, adapterID);
		System.out.println("\n");
	}
}
