package org.adapter;
import org.manager.AASensor;
import org.manager.ManagedResource;

public class AASocial {
	ManagedResource assessmentDocument;
	ManagedResource docNode;
	AASensor aa3Sensor1;
	
	public AASocial()
	{
	
		
	}
	

}
