package org.policy.parser;

import java.util.ArrayList;

public class Event {
	private String resourceID, resourceType, ref_sensor;
	private ArrayList<String> resource;
	
	private String[] depression_event = new String[] 
										{"first-diagnosis", "recovery-single-episode", 
										 "recovery-repeat-episode", "relapse", "dont-know"};
	private String depression_param;
	
	public Event() {
		resource = new ArrayList<String>();
	}
	
	
	
	public String getEventParam() {
		return depression_param;
	}
	
	public void setEventParam() {
		
		
		
		
		for(String element : depression_event)
		{
			if(element.equals("first-diagnosis")) {
				depression_param = "first-diagnosis";
				break;
				
			}
			
		}
		
	}

}
