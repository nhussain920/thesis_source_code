package org.policy.parser;

import java.util.ArrayList;

public class Policy {
	
	private String policyID, policyType, policyDescription, ref_aa;
	private String resourceID, resourceType, ref_sensor, ref_event;
	private String networkID, networkName;
	private String inputEventID, op;
	private String adapterID, adapterType;
	private String sensorID, sensorType;
	private String monitorID, conditionID, exprID, ref_monitor, ref_condition;
	private String varName, dataValue, contextID, ref_context, ref_expression;
	private String ruleID, condition;
	private String actionID, actionType, category, target_resource;
	private String executorID, message, ref_sender;
	private String action, ref_command, functionID, functionName;
	private String paramName, datavalue, inputActionID, ref_input_action;
	private String commandID, target_adapter;
	
	private Object AAPolicy, AA, ManagedResourceList, ManagedResource;
	private Object TriggerEvent, And, Or, Not;
	private Object SocialNetwork, NetworkResourceList, NetworkResource;
	private Object SensorList;
	private ArrayList<Object> Sensor;
	private ArrayList<Object> Event;
	
	public Policy() {
		//listOfActions = new ArrayList<Object>();

	}
	
	public void setPolicyID(String policyID) {
		this.policyID = policyID;
	}
	public String getPolicyID() {
		return policyID;
		
	}
	
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	
	
	public String getPolicyType() {
		return policyType;
		
	}
	
	public void setPolicyDescription(String policyDescription) {
		this.policyDescription = policyDescription;
	}
	
	public String getPolicyDescription() {
		return policyDescription;
		
	}
	
	public void setRefAA(String ref_aa) {
		this.ref_aa = ref_aa;
	}
	
	public String getRefAA() {
		return ref_aa;
		
	}
		
	
	
	
	
	
	public String getAdapterID() {
		return adapterID;
		
	}
	
	public void setAdapterID(String adapterID) {
		this.adapterID = adapterID;
	}
	
	public String getAdapterType() {
		return adapterType;
		
	}
	
	public void setAdapterType(String adapterType) {
		this.adapterType = adapterType;
	}
	
	
	
	public Object getAAPolicyElement() {
		return AAPolicy;
	}
	
	public void setAAPolicyElement(Object AAPolicy) {
		this.AAPolicy = AAPolicy;
	}
	
	public Object getConditionElement() {
		return condition;
	}
	
	public void setConditionElement(Object Condition) {
		this.condition = condition;
	}
	
	
	
	@Override
    public String toString() {
      //  return "Adapter="+this.adapterType+ " Policy Name="+this.policyType+ " Type="+this.policyType+" Event=" + this.eventID + " Condition=" 
   // + this.conditionID + " Actions=" ;
	return null;
	}
    

}