package org.policy.parser;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class PolicyFileHandler extends DefaultHandler{
	
	//List to hold policies objects
	private ArrayList<Policy> policySet;
	private Policy policy;
	private String tmpValue;
	
	public PolicyFileHandler() {
		policySet = new ArrayList<Policy>();
		policy = new Policy();
		parseDocument();
		//printPolicyList();
	}
	
	public void parseDocument() {
		File policyFile = new File("./src/policy.xml");
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		try {
			SAXParser parser = factory.newSAXParser();
		    parser.parse(policyFile, this);
		
		} catch(ParserConfigurationException e) {
			System.out.println("ParserConfig error");
		
		} catch(SAXException e) {
			System.out.println("SAXException : xml not well formed");
			
		} catch(IOException e) {
			System.out.println("IO error");
			
		}
	
	}//End parseDocument method
	
	@Override
	//Triggered when the start of tag is found.
	public void startElement(String uri, String localName, String elementName, Attributes attributes) 
			throws SAXException {
		if(elementName.equalsIgnoreCase("AAPolicy")) {
			//If current element is Policy, Create a new policy and put it in map
			//Clear tmpValue on start of element
			policy = new Policy();
			String policyID = attributes.getValue("policyID");
			String policyType = attributes.getValue("policyType");
			String policyDescription = attributes.getValue("policyDescription");
			String ref_aa = attributes.getValue("ref_aa");
			
			policy.setPolicyID(policyID);
			policy.setPolicyType(policyType);
			policy.setPolicyDescription(policyDescription);
			policy.setRefAA(ref_aa);
			
		}
		
	}//End startElement Method
	

	@Override
	//Triggered when the end of tag is found.
	public void endElement(String uri, String localName, String element) 
			throws SAXException {
		//If end of policy element add to arraylist
		
		if(element.equals("AAPolicy")) {
			policySet.add(policy);
			
		}
		
		if(element.equalsIgnoreCase("Event")) {
			//policy.setEvent(tmpValue);
		}
		
		if(element.equalsIgnoreCase("Condition")) {
			//policy.setCondition(tmpValue);
		}
		
		if(element.equalsIgnoreCase("Method")) {
			//policy.getAllActions().add(tmpValue);
		}
		
	}//End endElement method
	
	@Override
	//Triggered when the some text is found.
	public void characters(char[] ch, int start, int length ) 
		throws SAXException {
		tmpValue = new String(ch, start, length);
		
	}//End characters method
	
	//Print policy data from XML file
	public void printPolicyList() {
		for(Policy p : policySet) {
			System.out.println(p.toString());
		}
	}
	
	public ArrayList<Policy> getPolicies() {
		return policySet;
	}
	
	
}//End PolicySet class
