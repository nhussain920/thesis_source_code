package org.manager;

import java.util.ArrayList;
import java.util.HashMap;

public class PolicyData {
	
	private ArrayList<String> depression;
	private ArrayList<String> voice_act;
	private ArrayList<String> voice_urge_self;
	private ArrayList<String> voice_urge_other;
	private ArrayList<String> delusions;
	
	private ArrayList<String> context1, context2;
	private ArrayList<String> actions;
	
	public static String node_id, name, recepient, subject, txtMessage, population_restriction;

	
	public PolicyData() {
		depression = new ArrayList<String>();
		voice_act = new ArrayList<String>();
		voice_urge_self = new ArrayList<String>();
		voice_urge_other = new ArrayList<String>();
		delusions = new ArrayList<String>();
		
		context1 = new ArrayList<String>();
		context2 = new ArrayList<String>();
		actions = new ArrayList<String>();
		
		setDepressionData();
		setVoiceActData();
		setVoiceUrgeSelf();
		setVoiceUrgeOther();
		setDelusions();
		setExpression1();
		setExpression2();
		actionList();

		function();
	}
	
	public void setDepressionData() {
		depression.add("first-diagnosis");
		depression.add("Single-episode");
		depression.add("repeat-episode");
		depression.add("relapse");
		depression.add("dont-know");
		
	}
	
	public ArrayList<String> getDepressionData() {
		return depression;
		
	}
	
	public void setVoiceActData() {
		voice_act.add("0.6");
		voice_act.add("dont-know");
		voice_act.add("");
		voice_act.add("");
		voice_act.add("");
		
	}
	
	public ArrayList<String> getVoiceActData() {
		return voice_act;
		
	}
	
	public void setVoiceUrgeSelf() {
		voice_urge_self.add("0.2");
		voice_urge_self.add("dont-know");
		voice_urge_self.add("");
		voice_urge_self.add("");
		voice_urge_self.add("");
		
	}
	
	public ArrayList<String> getVoiceUrgeSelf() {
		return voice_urge_self;
		
	}
	
	public void setVoiceUrgeOther() {
		voice_urge_other.add("0.4");
		voice_urge_other.add("dont-know");
		voice_urge_other.add("");
		voice_urge_other.add("");
		voice_urge_other.add("");
		
	}
	
	public ArrayList<String> getVoiceUrgeOther() {
		return voice_urge_other;
		
	}
	
	public void setDelusions() {
		delusions.add("0.7");
		delusions.add("dont-know");
		delusions.add("");
		delusions.add("");
		delusions.add("");
		
	}
	
	public ArrayList<String> getDelusions() {
		return delusions;
		
	}
	
	public void setExpression1() {
		context1.add("low");
		context1.add("likely");
		context1.add("unlikely");
		context1.add("unlikely");
		context1.add("likely");
	}
	
	public ArrayList<String> getExpression1() {
		return context1;
	}
	
	public void setExpression2() {
		context2.add("medium");
		context2.add("likely");
		context2.add("likely");
		context2.add("unlikely");
		context2.add("unlikely");
	}
	
	public ArrayList<String> getExpression2() {
		return context2;
	}
	
	public void actionList() {
		actions.add("a1");
		actions.add("a2");
	}
	
	public ArrayList<String> getAction() {
		return actions;
	}
	
	public void function() {
		node_id = "n1";
		name = "John";
		recepient = "abc@example.come";
		subject = "medical advice";
		txtMessage = "We recommended you to seek help...";
		population_restriction = "older adults";
	}
	
	public String functionParam() {
		return node_id + name + recepient + subject + txtMessage + population_restriction;
	}
	
}
