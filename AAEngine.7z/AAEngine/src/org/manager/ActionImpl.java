package org.manager;

public class ActionImpl extends Action {
	
	public ActionImpl() {
		
	}
	
	public void openURL() {
		System.out.println("Called open_url action template....");
	}
	
	public void sendEmail(String id, String name, String recepient, String subject, String txtMessage, String population_restriction) {
		String nodeID = id;
		String personName = name;
		String recepientEmail = recepient;
		String emailSubject = subject;
		String message = txtMessage;
		String population = population_restriction;
		System.out.println("Sending email ... ");
		System.out.println("Email ID: " + nodeID + ", Person Name: " + personName + ", Email: " + recepientEmail
				+ ", Subject line: " + emailSubject + ", Message: " + message + ", Population Category: " + population);
		
	}
	
	public void dialEmergency() {
		System.out.println("Dialing emergency service....");
	}
}
