package org.manager;

public abstract class Monitor {
	public abstract boolean getNotified(AASensor s);
	public abstract boolean notifyLocalRIE();
	public abstract void setContext();

}
