package org.manager;

import java.util.ArrayList;

import org.interfaces.IManagedResource;
import org.interfaces.ISensor;

public class ManagedResource implements IManagedResource{
	private ArrayList<ISensor> sensors;  //list of sensor
	private Resource resource;  //name of the resource
	protected ArrayList<String> eventList;
	private String eventData;
	
	public ManagedResource(Resource resource) {
		this.resource = resource;
		this.sensors = new ArrayList<ISensor>();
		eventList = new ArrayList<String>();
		eventList.add("first-diagnosis");
		eventList.add("0.6");
		eventList.add("0.2");
		eventList.add("0.4");
		eventList.add("0.7");
	}
	
	public ArrayList<ISensor> getSensors() {
		return sensors;
	}
	
	public void setSensors(ArrayList<ISensor> sensors) {
		this.sensors = sensors;
	}
	
	//add sensor to the managed resources's registered sensor list
	@Override
	public void registerSensor(ISensor sensor) {
		sensors.add(sensor);
		System.out.println(sensor + " has started sensing event from " + resource);
	}
	
	//remove sensor from managed resource's registered sensor list
	@Override
	public void unregisterSensor(ISensor sensor) {
		sensors.remove(sensor);
		System.out.println(sensor + " has stopped sensing event from " + resource);
	}
	
	//Notify all the registered sensors
	@Override
	public void notifySensor(String eventData) {
		for(ISensor sensor : sensors)
		{
			sensor.update(resource, eventData);
		}
		
		System.out.println();
	}
	
	public void setEvent(String selectedEvent) {
		this.eventData = selectedEvent;
		this.eventList.add(eventData);
		System.out.println("\n" + resource + " has event value: " + this.eventData + "\n");
		notifySensor(eventData);
		
	}
	
	public ArrayList<String> getEvents() {
		
		return eventList;
		
	}
	
	@Override
	public Object getUpdate(ISensor obj) {
		return this.eventData;
	}
}
