package org.manager;

import org.interfaces.ISensor;

public class AASensor implements ISensor {
	private ManagedResource mr;
	private String sensorID, sensorType;
	protected String[] eventData;
	private boolean notification;
	
	public AASensor(String sensorID, String sensorType) {
		this.sensorID = sensorID;
		this.sensorType = sensorType;
		this.notification = false;
		this.mr = new ManagedResource(new Resource("","",""));
		this.eventData = new String[5];
	}
	
	
	@Override
	public void update(Resource resource , String eventdata) {
		System.out.println(sensorID + " has received event data from "+ resource + ", event value: "+  eventdata);
		this.notification = true;
	}
	
	
	public boolean notifyMonitor() {
		if(notification == true) {
			System.out.println("Sensor " + sensorID + " notified AA's Monitor");
			return true;
		}
		
		return false;
	}
	
	public void retrieveEventData() {
		System.out.print("Event Data: [");
		for(int i=0; i< mr.getEvents().size(); i++) {
			eventData[i] = mr.getEvents().get(i);
			System.out.print(" "+ eventData[i] + ",");
		}
		System.out.println("] retrieved by sensors\n");
	}
	
	public String[] getEventData() {
		return this.eventData;
	}
	
	
	public String toString() {
		return "Sensor " + sensorID + ", Sensor Type " + sensorType ;
	}
}
