package org.manager;

public abstract class Executor {
	public abstract boolean getNotified(GlobalRIE rie);
	public abstract void getCommand(String commandID, String actionID, String adapterID);
	public abstract void executeAction();
	public abstract void applyChanges();

}
