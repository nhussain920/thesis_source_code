package org.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.domain.AA1Executor_Depression;
import org.domain.AA1LocalRIE_Depression;

public class GlobalRIE {
	private HashMap<String, String> map;
	private String actionID, adapterID;
    private AA1LocalRIE_Depression aa1_rie;
    private AA1Executor_Depression aa1_executor;
    private String grieID;
    private boolean notification;
    private PolicyData policyData;
    
	public GlobalRIE(String grieID) {
		this.map = new HashMap<String, String>();
		this.grieID = grieID;
		this.notification = false;
		this.aa1_rie = new AA1LocalRIE_Depression("");
		this.aa1_executor = new AA1Executor_Depression("");
		this.policyData = new PolicyData();
	}
	
	public boolean getNotified(AA1LocalRIE_Depression rie) {
		if(rie.notifyGlobalRIE() == true) {
			System.out.println("Global RIE received notification from: " + rie.toString());
			this.notification = true;
			return true;
		}
		
		return false;
	}
	
	public boolean notifyExecutor() {
		if(this.notification == true) {
			System.out.println("Global RIE ID: " + grieID + " notified AA's Executor");
			
			return true;
		}
		
		return false;
	}
	
	public void addActions() {
      map.put(aa1_rie.getAction(), aa1_rie.toString());
      //map.put(aa2_rie.getAction(), aa2_rie.toString());
    }
	
	public void decision() {
		for (HashMap.Entry<String, String> entry : map.entrySet()) {
		    actionID = entry.getKey();
		    adapterID = entry.getValue();
		    
		    if(map.containsKey(actionID) && map.containsValue(adapterID)) {
		    	System.out.println("Execute action: " + actionID);
		    	aa1_executor.getCommand("cmd1", actionID, "AA1Depression");
		    }
		    
		    else if(map.containsKey("aa-rie1") && map.containsValue("a1")) {
		    	System.out.println("Execute action: " + actionID);
		    }
		
		    else {
		    	System.out.println("No action to execute");
		    }
		}
	}
	
	public void sendCommand(String actionID, String aa) {
		System.out.println("Command send to: " + adapterID);
	}
	
	
	public void printAction() {
		for(int i =0; i<policyData.getAction().size()-1; i++ ) {
			System.out.println("Send Action ID: " + policyData.getAction().get(i) + ", to AAs Executor: " + aa1_executor.toString());
		}
	}
	
	
	
	public String toString() {
		return "Global RIE " + grieID;
	}


}
