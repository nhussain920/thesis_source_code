package org.manager;

public abstract class Action {
	public abstract void openURL();
	public abstract void sendEmail(String id, String name, String recepient, String subject, String txtMessage, String population_restriction);
	public abstract void dialEmergency();

}
