package org.manager;

import org.domain.AA1Monitor_Depression;

public abstract class LocalRIE {
	public abstract boolean getNotified(AA1Monitor_Depression m);
	public abstract void triggerAction();
	public abstract boolean notifyGlobalRIE();

}
