package org.manager;

public class Resource {

	private String resourceID, resourceType;
	private String ref_sensor;
	
	public Resource(String resourceID, String resourceType, String ref_sensor) {
		this.resourceID = resourceID;
		this.resourceType = resourceType;
		this.ref_sensor = ref_sensor;
	}
	
	public String toString() {
		return "Resource ID: " + this.resourceID + ", type: " + this.resourceType + ", ref sensor: " + this.ref_sensor;
	}
	
}
